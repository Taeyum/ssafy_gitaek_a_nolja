<script setup>
import { MapPin, Users, MessageSquare, Sparkles } from 'lucide-vue-next'

// 부모 컴포넌트(App.vue)로 'start' 신호를 보내는 함수
const emit = defineEmits(['start'])
</script>

<template>
  <div class="min-h-screen bg-gray-50 font-sans">
    <header class="border-b bg-white/80 backdrop-blur-md sticky top-0 z-50 shadow-sm">
      <div class="container mx-auto px-6 py-4 flex items-center justify-between">
        <div class="flex items-center gap-2">
          <div class="w-10 h-10 rounded-2xl bg-[#DE2E5F] flex items-center justify-center shadow-lg shadow-pink-200">
            <MapPin class="h-5 w-5 text-white" />
          </div>
          <h1 class="text-2xl font-bold text-gray-900">Gitaek Anolja</h1>
        </div>
        <nav class="flex items-center gap-3">
          <button class="px-4 py-2 text-gray-500 hover:bg-gray-100 rounded-full transition-colors font-medium">
            로그인
          </button>
          <button class="px-4 py-2 bg-[#DE2E5F] text-white rounded-full hover:bg-[#c92552] transition-colors font-bold shadow-md">
            회원가입
          </button>
        </nav>
      </div>
    </header>

    <section class="container mx-auto px-6 py-24 text-center">
      <div class="max-w-3xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
        <h2 class="text-5xl md:text-6xl font-bold text-gray-900 leading-tight">
          친구들과 함께
          <br />
          <span class="text-[#DE2E5F]">실시간으로</span> 여행 계획하기
        </h2>
        <p class="text-xl text-gray-500 leading-relaxed">
          기택 아놀자에서 국내 여행을 함께 계획하고, 실시간으로 소통하며,<br class="hidden md:block" />
          AI 추천으로 완벽한 일정을 만들어보세요.
        </p>
        <div class="flex items-center justify-center gap-4 pt-4">
          <button 
            @click="emit('start')"
            class="text-lg px-8 py-4 rounded-full bg-[#DE2E5F] text-white hover:bg-[#c92552] shadow-xl hover:shadow-2xl hover:-translate-y-1 transition-all flex items-center font-bold"
          >
            <Users class="mr-2 h-5 w-5" />
            그룹 만들기
          </button>
          
          <button class="text-lg px-8 py-4 rounded-full border-2 border-gray-200 bg-white hover:border-[#DE2E5F] hover:text-[#DE2E5F] transition-all font-bold">
            참여 코드로 입장
          </button>
        </div>
      </div>
    </section>

    <section class="container mx-auto px-6 py-16">
      <div class="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
        <div class="bg-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-all hover:-translate-y-1 duration-300">
          <div class="h-16 w-16 rounded-2xl bg-[#DE2E5F]/10 flex items-center justify-center mb-6">
            <MapPin class="h-8 w-8 text-[#DE2E5F]" />
          </div>
          <h3 class="text-2xl font-bold mb-3 text-gray-900">지도 기반 계획</h3>
          <p class="text-gray-500 leading-relaxed">
            지도에서 여행지를 검색하고 일정에 추가하여 직관적으로 루트를 계획하세요.
          </p>
        </div>

        <div class="bg-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-all hover:-translate-y-1 duration-300 delay-100">
          <div class="h-16 w-16 rounded-2xl bg-orange-100 flex items-center justify-center mb-6">
            <MessageSquare class="h-8 w-8 text-orange-500" />
          </div>
          <h3 class="text-2xl font-bold mb-3 text-gray-900">실시간 협업</h3>
          <p class="text-gray-500 leading-relaxed">
            친구들과 실시간으로 채팅하며 의견을 나누고 함께 일정을 수정하세요.
          </p>
        </div>

        <div class="bg-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-all hover:-translate-y-1 duration-300 delay-200">
          <div class="h-16 w-16 rounded-2xl bg-purple-100 flex items-center justify-center mb-6">
            <Sparkles class="h-8 w-8 text-purple-600" />
          </div>
          <h3 class="text-2xl font-bold mb-3 text-gray-900">AI 추천</h3>
          <p class="text-gray-500 leading-relaxed">
            AI가 여행 스타일에 맞는 최적의 여행지와 루트를 추천해드립니다.
          </p>
        </div>
      </div>
    </section>

    <footer class="border-t bg-white mt-12">
      <div class="container mx-auto px-6 py-8 text-center text-sm text-gray-400">
        <p>&copy; 2025 Gitaek Anolja. All rights reserved.</p>
      </div>
    </footer>
  </div>
</template>