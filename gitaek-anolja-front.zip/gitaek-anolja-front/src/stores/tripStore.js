import { ref } from 'vue'
import { defineStore } from 'pinia'

export const useTripStore = defineStore('trip', () => {
  // 1. 상태 (State)
  const itinerary = ref([
    {
      id: "1", day: "1일차", date: "2025.01.15",
      items: [
        { id: "1-1", time: "09:00", name: "제주 공항 도착", location: "제주국제공항", lat: 33.5104, lng: 126.4913 },
        { id: "1-2", time: "11:00", name: "성산일출봉", location: "서귀포시 성산읍", lat: 33.4582, lng: 126.9427 },
      ],
    },
    {
      id: "2", day: "2일차", date: "2025.01.16",
      items: [],
    },
  ])

  // 2. 액션 (Action)
  
  // ★★★ [여기가 중요합니다!] 파라미터에 'time'이 있어야 합니다. ★★★
  const addPlace = (dayId, place, time) => {
    const targetDay = itinerary.value.find(d => d.id === dayId)
    if (targetDay) {
      targetDay.items.push({
        id: Date.now().toString(),
        // 받은 시간이 있으면 그걸 쓰고, 없으면 12:00으로 저장
        time: time ? time : "12:00", 
        name: place.name,
        location: place.address,
        lat: place.lat,
        lng: place.lng
      })
      
      // 시간을 기준으로 자동 정렬 (오전 9시 -> 오후 2시 순서대로)
      targetDay.items.sort((a, b) => a.time.localeCompare(b.time))
    }
  }

  const removePlace = (dayId, itemId) => {
    const targetDay = itinerary.value.find(d => d.id === dayId)
    if (targetDay) {
      targetDay.items = targetDay.items.filter(item => item.id !== itemId)
    }
  }

  const updateItems = (dayId, newItems) => {
    const targetDay = itinerary.value.find(d => d.id === dayId)
    if (targetDay) {
      targetDay.items = newItems
    }
  }

  return { itinerary, addPlace, removePlace, updateItems }
})