package com.ssafy.gitaek;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GitaekApplicationTests {

	@Test
	void contextLoads() {
	}

}
